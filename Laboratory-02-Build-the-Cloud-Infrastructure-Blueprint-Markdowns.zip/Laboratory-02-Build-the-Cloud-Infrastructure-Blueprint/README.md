# Laboratory 02 – Build the Cloud Infrastructure Blueprint

## Mission Overview

This laboratory activity focused on investigating the basic components of cloud infrastructure using the KillerCoda Playground. The Linux environment was examined to identify compute, storage, networking, and operating system resources.

## Objectives

- Explain the major components of cloud infrastructure.
- Investigate hardware and software resources in a Linux environment.
- Differentiate compute, storage, networking, and operating system resources.
- Explain how infrastructure components work together.
- Compare services from AWS, Microsoft Azure, and Google Cloud.
- Create technical documentation using Markdown.

## Tools Used

- KillerCoda Playground
- Ubuntu Linux terminal
- GitHub
- Markdown
- Screenshot tools

## Linux Commands Executed

```bash
cat /etc/os-release
uname -r
lscpu
nproc
free -h
df -h
lsblk
hostname
ip a
```

## Skills Learned

- Navigating a Linux terminal
- Checking operating system information
- Identifying CPU and memory resources
- Checking disk capacity and mounted file systems
- Finding the hostname and IP address
- Explaining cloud infrastructure components
- Organizing technical documentation in GitHub

## Screenshots

The evidence screenshots are stored in the `screenshots` folder:

- `server-information.png`
- `network-information.png`
- `storage-information.png`
- `cloud-architecture.png`
