# Infrastructure Report

## 1. Operating System

- **Operating System:** Ubuntu 24.04.4 LTS
- **Codename:** Noble Numbat

The operating system provides the environment used to manage system resources and execute Linux commands.

## 2. Kernel Version

- **Kernel Version:** 6.8.0-136-generic

The kernel manages communication between the operating system and the system hardware or virtual resources.

## 3. CPU Information

- **CPU Model:** Intel Xeon E312xx (Sandy Bridge)
- **Number of CPU Cores:** 1
- **Architecture:** x86_64

The CPU is the compute resource that processes instructions and runs programs inside the Linux environment.

## 4. Memory Information

- **Total RAM:** Approximately 1.9 GiB
- **Available Memory:** Approximately 1.4 GiB at the time of checking

RAM temporarily holds data and instructions needed by running processes.

## 5. Disk and File System Information

- **Disk Capacity:** Approximately 20G
- **Root File System:** `/`
- **Boot File System:** `/boot`
- **EFI File System:** `/boot/efi`

The disk stores the operating system, files, and other data used by the cloud server.

## 6. Hostname

- **Hostname:** `ubuntu`

The hostname identifies the Linux machine within its environment.

## 7. IP Address and Network

- **Network Interface:** `enp1s0`
- **IP Address:** `172.30.1.2/24`
- **Docker Network:** `docker0`
- **Docker Network Address:** `172.17.0.1/16`

The network interface allows the server to communicate with other systems. The Docker network provides networking for Docker containers.

## 8. Evidence

The supporting screenshots are stored in the `screenshots` folder.
