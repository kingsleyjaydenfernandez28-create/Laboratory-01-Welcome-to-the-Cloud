# Cloud Components

## 1. Compute Resources

Compute resources are processing resources used to execute commands, run applications, and perform calculations. Examples include CPUs, virtual machines, and containers.

The KillerCoda environment provided a virtual Linux server with an Intel Xeon CPU and one CPU core. The CPU processed the Linux commands used during the investigation.

## 2. Storage Resources

Storage resources hold the operating system, files, application data, and other information. Storage can be provided through virtual disks, block storage, file storage, or object storage.

The Linux environment showed a virtual disk with approximately 20G of capacity. The disk contained mounted file systems such as `/`, `/boot`, and `/boot/efi`.

## 3. Networking Resources

Networking resources allow systems, applications, and users to communicate. Examples include network interfaces, IP addresses, routers, and virtual networks.

The server used the `enp1s0` network interface and had the IP address `172.30.1.2/24`. The environment also showed a `docker0` interface for Docker networking.

## 4. Operating System

An operating system manages computer resources and provides tools for users and applications. Linux is commonly used in cloud environments.

The server used Ubuntu 24.04.4 LTS with kernel version 6.8.0-136-generic. The terminal allowed the user to inspect the server using Linux commands.
