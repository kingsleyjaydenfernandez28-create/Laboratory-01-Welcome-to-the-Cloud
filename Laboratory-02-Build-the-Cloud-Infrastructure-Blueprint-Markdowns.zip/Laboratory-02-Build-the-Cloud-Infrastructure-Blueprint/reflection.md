# Mission Reflection

## 1. Which cloud infrastructure component do you think is the most important? Why?

I think compute resources are one of the most important cloud infrastructure components because they run applications and process instructions. Without compute resources, services would not be able to perform tasks. However, compute also needs storage, networking, and an operating system to work properly.

## 2. How does Linux support cloud computing?

Linux supports cloud computing by providing a stable and flexible operating system for servers. It includes command-line tools that allow administrators to inspect resources, manage files, configure networking, and monitor system performance. Linux is useful in cloud environments because it can be automated and managed efficiently.

## 3. Why is technical documentation important before deploying infrastructure?

Technical documentation is important because it records the resources, configurations, and decisions involved in a project. It helps engineers understand the current environment and identify possible problems before deployment. Documentation also makes troubleshooting, maintenance, and teamwork easier.

## 4. What new skills did you learn during this laboratory activity?

I learned how to use Linux commands to check the operating system, kernel, CPU, RAM, disk capacity, mounted file systems, hostname, and IP address. I also learned how to identify compute, storage, networking, and operating system components. In addition, I practiced organizing technical information using Markdown.

## 5. How has your GitHub portfolio improved after completing this mission?

My GitHub portfolio improved because I added a structured laboratory folder with reports, comparisons, reflections, and screenshots. The folder makes my work easier to organize and review. It also shows my progress in learning cloud computing, Linux commands, technical documentation, and basic infrastructure planning.
