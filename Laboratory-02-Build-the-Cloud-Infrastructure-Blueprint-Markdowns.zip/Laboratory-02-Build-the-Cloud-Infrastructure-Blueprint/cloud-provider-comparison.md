# Cloud Provider Comparison

## Service Comparison

| Infrastructure Component | Amazon Web Services (AWS) | Microsoft Azure | Google Cloud Platform (GCP) |
|---|---|---|---|
| Compute | Amazon EC2 | Azure Virtual Machines | Compute Engine |
| Storage | Amazon S3 / Amazon EBS | Azure Blob Storage / Managed Disks | Cloud Storage / Persistent Disk |
| Networking | Amazon VPC | Azure Virtual Network | Virtual Private Cloud (VPC) |
| Identity and Access Management | AWS IAM | Microsoft Entra ID and Azure RBAC | Cloud Identity and IAM |

## Guide Questions

### 1. Which cloud provider offers the broadest range of services?

AWS, Azure, and Google Cloud all provide a wide range of cloud services. The exact range depends on the service categories and comparison method being used.

### 2. Which cloud platform would be suitable for an organization that primarily uses Microsoft products?

Microsoft Azure may be suitable because it integrates with Microsoft services and technologies. The organization should still compare its existing systems, security requirements, budget, and technical needs before making a final decision.

### 3. Which platforms provide AI, machine learning, and Kubernetes services?

All three cloud providers offer artificial intelligence, machine learning, and Kubernetes services. Google Cloud provides services such as Vertex AI and Google Kubernetes Engine, while AWS and Azure also provide comparable services.

### 4. What similarities did you observe among the three cloud providers?

All three providers offer compute, storage, networking, and identity and access management services. They also provide scalable infrastructure, security controls, monitoring tools, and services that can be managed through web consoles, command-line tools, and APIs.

## Official Documentation Links

- AWS: https://aws.amazon.com/products/
- Microsoft Azure: https://azure.microsoft.com/en-us/products/
- Google Cloud: https://cloud.google.com/products
